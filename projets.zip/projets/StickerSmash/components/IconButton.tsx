import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { Pressable, StyleSheet, Text } from 'react-native';
import { MaterialIconName } from '../interfaces/MaterialIconName';

interface IconButtonProps {
  icon: MaterialIconName;
  label: string;
  onPress: () => unknown;
}

export default function IconButton({ icon, label, onPress }: IconButtonProps) {
  return (
    <Pressable
      style={styles.iconButton}
      onPress={onPress}
      accessibilityLabel={label}
    >
      <MaterialIcons name={icon} size={24} color="#fff" />
      <Text style={styles.iconButtonLabel}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  iconButton: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconButtonLabel: {
    color: '#fff',
    marginTop: 12,
  },
});
