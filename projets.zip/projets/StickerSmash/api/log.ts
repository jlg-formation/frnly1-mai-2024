const url = 'http://localhost:3000/api/log';

export const postLog = async () => {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ toto: 123 }),
    });
    const obj = await response.json();
    console.log('obj: ', obj);
  } catch (err) {
    console.log('err: ', err);
  }
};
