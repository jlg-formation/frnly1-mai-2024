describe("template spec", () => {
  it("passes", () => {
    cy.visit("http://localhost:8081");

    cy.contains("Choose a Photo", {
      matchCase: false,
    });
    cy.contains("Use this photo").click();
    cy.get("[aria-label='Reset']").click();

    cy.contains("Use this photo").click();
    cy.get("[aria-label='Add']").click();

    cy.get("[aria-label='goat']").click();

    cy.get("[aria-label='EmojiSticker']").click().click();

    cy.get("[aria-label='EmojiSticker']").should("have.css", "width", "80px");
    cy.get("[aria-label='EmojiSticker']")
      .click()
      .click()
      .should("have.css", "width", "40px");
  });
});
