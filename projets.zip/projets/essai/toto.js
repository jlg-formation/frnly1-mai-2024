var qq = "machin";

module.exports = qq;
